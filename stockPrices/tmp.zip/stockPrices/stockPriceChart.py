import json, urllib2, easygui, time
import matplotlib
import matplotlib.pyplot as plt
import matplotlib.dates as mdate
import numpy as np

symbol, country = easygui.multenterbox('Choose your stock:', fields = ['Symbol', 'Country'], values = [])

if not symbol:
	easygui.msgbox('You did not enter a symbol!')
else:
	url = 'http://www.bloomberg.com/markets/chart/data/1D/' + symbol + ':' + country
	response = urllib2.urlopen(url)
	data = json.load(response)

	datapoints = data['data_values']

	if not datapoints:
		easygui.msgbox('Stock symbol not found')
	else:
		rawTimes = []
		prices = []

		for point in datapoints:
			rawTimes.append(point[0] // 1000)
			prices.append(point[1])

		times = mdate.epoch2num(rawTimes)

		font = {'size' : 12}
		matplotlib.rc('font', **font)

		fig, ax = plt.subplots()

		# ax.plot_date(times, prices, linewidth = 3, label = symbol)
		ax.plot(times, prices, linewidth = 3, label = symbol)

		date_fmt = '%H:%M:%S'

		date_formatter = mdate.DateFormatter(date_fmt)
		ax.xaxis.set_major_formatter(date_formatter)

		# fig.autofmt_xdate()

		start_time = time.gmtime(rawTimes[0])
		fmt = '%Y-%m-%d'
		day = time.strftime(fmt, start_time)


		plt.xlim(times[0], times[-1])
		plt.xlabel('Time', size = 15)
		plt.ylabel('Stock price ($)', size = 15)
		plt.legend(loc = 1)
		plt.title('Stock price of ' + symbol + ':' + country + ' on ' + day, size = 15)
		# plt.show()

		plt.savefig(symbol + '_' + country + '_' + day + '.pdf')