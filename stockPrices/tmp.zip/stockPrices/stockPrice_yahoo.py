import urllib2, re
from bs4 import BeautifulSoup

symbol = 'AAPL'

def getStockPrice(symbol):

	url = 'https://finance.yahoo.com/q?s=' + symbol

	response = urllib2.urlopen(url)
	content = response.read()

	soup = BeautifulSoup(content, "html.parser")
	price = soup.find('span', {'id': 'yfs_l84_' + symbol.lower()})

	# regex = '<span id="yfs_l84_aapl">(.+?)</span>'
	# pattern = re.compile(regex)
	# price = re.findall(pattern, content)

	return price.string


f = open('NASDAQ_Symbols.txt')
symbols = f.read().split('\n')

for symbol in symbols[:5]:
	print(symbol + ': $' + getStockPrice(symbol))

# symbols = ['AAPL', 'SPY', 'GOOG', 'NFLX', 'FB', 'AMZN', 'LNKD', 'TWTR']
# for symbol in symbols:
# 	print(symbol + ': $' + getStockPrice(symbol))