import datetime, pytz, time, random

utc = pytz.utc
# print(utc.zone)

est = pytz.timezone('US/Eastern')
# print(est.zone)

aest = pytz.timezone('Australia/Sydney')
# print(aest.zone)

ctz = pytz.timezone('Asia/Urumqi')
# print(ctz.zone)


# aest_moment = aest.localize(datetime.datetime.now())
# utc_moment = aest_moment.astimezone(utc)
# est_moment = aest_moment.astimezone(est)
# ctz_moment = aest_moment.astimezone(ctz)

# print 'utc:', utc_moment
# print 'est:', est_moment
# print 'ctz:', ctz_moment

# for tz in pytz.all_timezones:
# 	print tz


def epochConversion(epochTimes, tzOrg, tzFin):
	final_time = []
	for epochTime in epochTimes:
		org_moment = datetime.datetime.utcfromtimestamp(epochTime).replace(tzinfo = tzOrg)
		fin_moment = org_moment.astimezone(tzFin)
		final_time.append(fin_moment)
	return final_time

epochTimes = [1456738320 + 100 * i for i in range(100)]
tzOrg = est
tzFin = aest

final_time = epochConversion(epochTimes, tzOrg, tzFin)
price = [random.randint(10, 100) for _ in range(100)]

import matplotlib.pyplot as plt

plt.plot(final_time, price)
plt.show()