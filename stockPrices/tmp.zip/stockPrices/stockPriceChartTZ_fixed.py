import json, urllib2, pytz, datetime, os
import matplotlib.pyplot as plt

def dailyPrice(symbol, country):
	url = 'http://www.bloomberg.com/markets/chart/data/1D/' + symbol + ':' + country
	response = urllib2.urlopen(url)
	data = json.load(response)

	datapoints = data['data_values']

	epochTimes = []
	prices = []

	for dp in datapoints:
		rawTime, price = dp
		epochTimes.append(rawTime // 1000)
		prices.append(price)

	est = pytz.timezone('US/Eastern')
	aest = pytz.timezone('Australia/Sydney')
	ctz = pytz.timezone('Asia/Urumqi')

	tzMAP = {'US': est, 'AU': aest, 'CH': ctz}
	currencyMAP = {'US': 'USD', 'AU': 'AUD', 'CH': 'CNY'}

	tzOrg = est
	tzFin = tzMAP[country]

	final_time = epochConversion(epochTimes, tzOrg, tzFin)

	tradingDate = str(final_time[0])[:10]

	fig = plt.figure()
	plt.plot(final_time, prices, label = symbol)
	plt.xlabel('Time', size = 15)
	plt.ylabel('Stock price ' + '(' + currencyMAP[country] + ')', size = 15)
	plt.legend(loc = 1)
	plt.title('Stock price of ' + symbol + ':' + country + ' on ' + tradingDate, size = 15)
	# plt.show()
	plt.savefig('stocksOfInterest/' + symbol + '_' + country + '_' + tradingDate + '.pdf')
	plt.close(fig)

def epochConversion(epochTimes, tzOrg, tzFin):
	final_time = []
	for epochTime in epochTimes:
		org_moment = datetime.datetime.utcfromtimestamp(epochTime).replace(tzinfo = tzOrg)
		fin_moment = org_moment.astimezone(tzFin)
		final_time.append(fin_moment)
	return final_time

newFolder = 'stocksOfInterest' 
if not os.path.exists(newFolder):
	os.makedirs(newFolder)

symbol_country = [['BAL', 'AU'], ['FB', 'US'], ['300274', 'CH']]

for c_s in symbol_country:
	symbol, country = c_s
	dailyPrice(symbol, country)