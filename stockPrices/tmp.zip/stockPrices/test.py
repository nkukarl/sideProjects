import urllib2, re

url = 'http://www.google.com'
url = 'http://www.cnn.com'
url = 'http://www.nytimes.com/'

regex = '<title>(.+?)</title>'
pattern = re.compile(regex)

response = urllib2.urlopen(url)
content = response.read()
title = re.findall(pattern, content)

print(title)