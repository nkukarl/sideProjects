import json, urllib2, os, time
# using bloomberg website and json library of python

# symbols = ['AAPL', 'SPY', 'GOOG', 'NFLX', 'FB', 'AMZN', 'LNKD', 'TWTR']
# for symbol in symbols:
# 	url = 'http://www.bloomberg.com/markets/watchlist/recent-ticker/' + symbol + ':US'
# 	response = urllib2.urlopen(url)
# 	data = json.load(response)
# 	print(data['disp_name'] + ': $' + str(data['last_price']))

def dailyPrice(symbol):
	url = 'http://www.bloomberg.com/markets/chart/data/1D/' + symbol + ':US'
	response = urllib2.urlopen(url)
	data = json.load(response)

	f = open('dailyPrices/' + symbol + '.csv', 'w+')
	datapoints = data['data_values']
	f.write('time,price\n')
	f.close()

	fmt = '%Y-%m-%d %H:%M:%S'
	f = open('dailyPrices/' + symbol + '.csv', 'a')
	for dp in datapoints:
		print(dp[0] // 1000)
		tmp = time.gmtime(dp[0] // 1000)
		formatted_time = time.strftime(fmt, tmp)
		price = str(dp[1])
		f.write(formatted_time + ',' + price + '\n')

symbols = ['AAPL', 'GOOG', 'NFLX', 'FB', 'AMZN', 'LNKD', 'TWTR']

newFolder = 'dailyPrices' 
if not os.path.exists(newFolder):
	os.makedirs(newFolder)

for symbol in symbols[:1]:
	dailyPrice(symbol)