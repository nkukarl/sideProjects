import urllib2, re
from bs4 import BeautifulSoup

def getStockPrice(symbol):

	url = 'https://www.google.com/finance?q=' + symbol

	response = urllib2.urlopen(url)
	content = response.read()

	# soup = BeautifulSoup(content, "html.parser")
	# price = soup.find('span', {'id': 'yfs_l84_' + symbol.lower()})

	regex = '<span id="ref_\d+_l">(.+?)</span>'
	pattern = re.compile(regex)
	price = re.findall(pattern, content)

	return price[0]

# symbols = ['AAPL', 'SPY', 'GOOG', 'NFLX', 'FB', 'AMZN', 'LNKD', 'TWTR']
# for symbol in symbols:
# 	print(symbol + ': $' + getStockPrice(symbol))

# # optimised (AAPL only)
# url = 'https://www.google.com/finance/getprices?q=AAPL&x=NASD&i=120&p=25m&f=c&df=cpct&auto=1&ts=1456640181915&ei=eJDSVtnfHMaN0gTJ2LbYDA'
# response = urllib2.urlopen(url)
# content = response.read()
# print(content.split()[-1])