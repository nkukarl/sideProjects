from threading import Thread
from bs4 import BeautifulSoup
import urllib2
import MySQLdb

MAP = dict()

def th(symbol):
	url = 'https://finance.yahoo.com/q?s=' + symbol
	content = urllib2.urlopen(url).read()
	soup = BeautifulSoup(content, 'html.parser')
	data = soup.find('span', {'id': 'yfs_l84_' + symbol.lower()})
	price = data.string
	MAP[symbol] = price
	# print MAP

symbols = ['AAPL', 'GOOG', 'NFLX', 'FB', 'AMZN', 'LNKD', 'TWTR']

# f = open('NASDAQ_Symbols.txt')
# symbols = f.read().split('\n')

for symbol in symbols:
	th(symbol)

for k, v in MAP.items():
	print k, v

db = MySQLdb.connect('localhost', 'root', '19891004', 'stockPrice')