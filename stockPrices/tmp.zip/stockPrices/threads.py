from threading import Thread
from bs4 import BeautifulSoup
import urllib2

def th(symbol):
	# url = 'http://www.bloomberg.com/quote/' + symbol + ':US'
	url = 'https://finance.yahoo.com/q?s=' + symbol
	content = urllib2.urlopen(url).read()
	soup = BeautifulSoup(content, 'html.parser')
	price = soup.find('span', {'id': 'yfs_l84_' + symbol.lower()})
	if price:
		print(symbol + ': ' + price.string + '#')

# symbols = ['AAPL', 'GOOG', 'NFLX', 'FB', 'AMZN', 'LNKD', 'TWTR']

f = open('NASDAQ_Symbols.txt')
symbols = f.read().split('\n')

threadlist = []

for symbol in symbols[:50]:
	t = Thread(target = th, args = (symbol,))
	t.start()
	threadlist.append(t)

for thl in threadlist:
	thl.join()

# for symbol in symbols[:10]:
# 	th(symbol)