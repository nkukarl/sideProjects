from captcha.image import ImageCaptcha
from captcha.audio import AudioCaptcha
import string
import random

chars = string.ascii_letters
text = ''.join(random.sample(chars, 5))

inst = ImageCaptcha()

# data = inst.generate(text)

print text
inst.write(text, 'output.png')

digits = '0123456789'
sound = ''.join(random.sample(digits, 5))
print sound
inst = AudioCaptcha()
inst.write(sound, 'output.wav')