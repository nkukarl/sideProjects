import copy

class SudokuSolver:
	def __init__(self, Q):
		self.Q = Q

	def display(self):
		# display sudoku board
		for row in self.Q:
			for n in row:
				print n,
			print

	def qCheck(self):
		if not self.Q:
			return False
		Q, n = len(self.Q), len(self.Q[0])
		if Q != 9 or n != 9:
			return False

		# check rows
		for r in range(Q):
			tmp = []
			for c in range(n):
				if self.Q[r][c] != 0:
					tmp.append(self.Q[r][c])
			if len(tmp) != len(set(tmp)):
				return False

		# check columns
		for c in range(n):
			tmp = []
			for r in range(Q):
				if self.Q[r][c] != 0:
					tmp.append(self.Q[r][c])
			if len(tmp) != len(set(tmp)):
				return False

		# check blocks:
		for r in [0, 3, 6]:
			for c in [0, 3, 6]:
				tmp = []
				for vShift in range(3):
					for hShift in range(3):
						if self.Q[r + vShift][c + hShift] != 0:
							tmp.append(self.Q[r + vShift][c + hShift])
				if len(tmp) != len(set(tmp)):
					return False

		return True

	def solve(self):
		if not self.qCheck():
			return 'Invalid input'
		self.ans = None
		self.helper(0, self.Q)
		if self.ans:
			return self.ans
		return 'No solution found'

	def helper(self, idx, board):
		# print board
		if idx == 81:
			self.ans = board
			return
		else:
			row = idx // 9
			col = idx % 9
			if board[row][col] != 0:
				self.helper(idx + 1, board)
			else:
				for val in range(1, 10):
					if self.valCheck(board, row, col, val):
						tmp = board[:row] + [board[row][:col] + [val] + board[row][col + 1:]] + board[row + 1:]
						self.helper(idx + 1, tmp)

	def valCheck(self, board, row, col, val):

		# check row
		for c in range(9):
			if board[row][c] == val:
				return False

		# check column
		for r in range(9):
			if board[r][col] == val:
				return False

		# check block
		blockRow = row // 3
		blockCol = col // 3

		# print row, col, blockRow, blockCol

		for vShift in range(3):
			for hShift in range(3):
				if board[blockRow * 3 + vShift][blockCol * 3 + hShift] == val:
					return False

		return True

Q = [[5,3,0,0,7,0,0,0,0], [6,0,0,1,9,5,0,0,0], [0,9,8,0,0,0,0,6,0], [8,0,0,0,6,0,0,0,3], [4,0,0,8,0,3,0,0,1], [7,0,0,0,2,0,0,0,6], [0,6,0,0,0,0,2,8,0], [0,0,0,4,1,9,0,0,5], [0,0,0,0,8,0,0,7,9]]

Q =[[0,0,0,6,0,0,1,4,2], [0,2,6,0,0,0,0,0,0], [7,0,0,0,0,4,0,0,9], [0,0,0,0,0,6,2,0,0], [0,6,0,9,0,1,0,5,0], [0,0,5,3,0,0,0,0,0], [9,0,0,4,0,0,0,0,7], [0,0,0,0,0,0,8,1,0], [8,4,2,0,0,7,0,0,0]]

Q = [[8,1,4,0,0,0,0,0,2],[2,0,0,7,0,8,1,0,0],[5,7,3,1,0,0,0,0,4],[0,0,7,0,1,0,0,9,0],[0,0,0,6,0,9,0,0,0],[0,4,0,0,7,0,3,0,0],[4,0,0,0,0,7,6,3,5],[0,0,9,2,0,3,0,0,1],[3,0,0,0,0,0,7,2,9]]

Q = [[0,3,0,0,0,0,2,0,4],[0,7,9,0,0,0,0,6,0],[2,6,1,0,7,0,0,0,9],[9,0,0,7,0,0,0,8,0],[8,5,3,0,6,0,7,1,2],[0,4,0,0,0,2,0,0,3],[3,0,0,0,8,0,5,4,1],[0,1,0,0,0,0,8,2,0],[7,0,5,0,0,0,0,3,0]]

Q = [[0,3,5,0,0,1,7,0,0], [6,0,0,9,0,7,8,0,0], [0,1,0,0,0,0,0,0,6], [0,7,4,6,0,0,0,0,5], [8,0,3,0,0,0,9,0,7], [5,0,0,0,0,4,6,8,0], [3,0,0,0,0,0,0,1,0], [0,0,6,2,0,9,0,0,3], [0,0,9,7,0,0,4,6,0]]

Q = [[0,2,0,0,3,0,0,4,0], [6,0,0,0,0,0,0,0,3], [0,0,4,0,0,0,5,0,0], [0,0,0,8,0,6,0,0,0], [8,0,0,0,1,0,0,0,6], [0,0,0,7,0,5,0,0,0], [0,0,7,0,0,0,6,0,0], [4,0,0,0,0,0,0,0,8], [0,3,0,0,4,0,0,2,0]]


obj = SudokuSolver(Q)

# obj.display()

# print obj.qCheck()

ans = obj.solve()

for row in ans:
	for n in row:
		print n,
	print