from PIL import Image
import pytesseract
import glob

images = glob.glob('./*.png')
# images = glob.glob('./*.jpg')

for img in images:
	print img
	print pytesseract.image_to_string(Image.open(img))
	print '=' * 20


print pytesseract.image_to_string(Image.open('tmp0_3.png'), config='-psm 10')