import time
class SudokuSolver:
	def solve(self, board):

		self.possibleVals(board)
		self.helper(board)

	def possibleVals(self, board):
		'''
		Create a dictionary self.valsMap to store the possible values for each location
		Each dictionary entry in the format of (r, c) = [val1, val2, ...]
		'''
		self.valsMap = dict() # Dictionary initialisation
		for row in range(9):
			for col in range(9):
				
				if board[row][col] == 0: # only search for locations with 0
					vals = [n + 1 for n in range(9)] # all possible values
					key = (row, col)
					unavail = set() # unavailable values initialised to empty
					
					# check values existing in the same row and add them to unavail
					for c in range(9):
						if board[row][c] != 0:
							unavail.add(board[row][c])

					# check values existing in the same column and add them to unavail
					for r in range(9):
						if board[r][col] != 0:
							unavail.add(board[r][col])

					# check values existing in the same block and add them to unavail
					for vShift in range(3): # vertical shift
						for hShift in range(3): # horizontal shift
							r, c = row // 3 * 3 + vShift, col // 3 * 3 + hShift
							if board[r][c]:
								unavail.add(board[r][c])

					# remove values in unavail from all possible values
					for val in unavail:
						vals.remove(val)

					# create a dictionary entry
					self.valsMap[key] = vals

	def isValid(self, board, x, y):
		tmp = board[x][y]
		board[x][y] = '$'
		for i in range(9):
			if board[i][y] == tmp:
				return False
		for j in range(9):
			if board[x][j] == tmp:
				return False
		for i in range(3):
			for j in range(3):
				if board[x // 3 * 3 + i][y // 3 * 3 + j] == tmp:
					return False
		board[x][y] = tmp
		return True

	def helper(self, board):
		for i in range(9):
			for j in range(9):
				if board[i][j] == 0:
					for val in self.valsMap[(i, j)]:
						board[i][j] = val
						if self.isValid(board, i, j) and self.helper(board):
							return True
						board[i][j] = 0
					return False
		return True

board = [[0,2,0,0,3,0,0,4,0], [6,0,0,0,0,0,0,0,3], [0,0,4,0,0,0,5,0,0], [0,0,0,8,0,6,0,0,0], [8,0,0,0,1,0,0,0,6], [0,0,0,7,0,5,0,0,0], [0,0,7,0,0,0,6,0,0], [4,0,0,0,0,0,0,0,8], [0,3,0,0,4,0,0,2,0]]


obj = SudokuSolver()

obj.solve(board)

for row in board:
	for n in row:
		print n,
	print

# 9 2 5 6 3 1 8 4 7
# 6 1 8 5 7 4 2 9 3
# 3 7 4 9 8 2 5 6 1
# 7 4 9 8 2 6 1 3 5
# 8 5 2 4 1 3 9 7 6
# 1 6 3 7 9 5 4 8 2
# 2 8 7 3 5 9 6 1 4
# 4 9 1 2 6 7 3 5 8
# 5 3 6 1 4 8 7 2 9