class SudokuSolver:
	def solveSudoku(self, board):
		val=self.PossibleVals(board) # dict {(i,j):[possible values]}
		print val
		self.Solver(board,val)

	def PossibleVals(self,board):
		num="123456789"
		val={}
		d={(i/3,j/3):[] for i in xrange(9) for j in xrange(9)}
		d.update({("row", i):[] for i in xrange(9)})
		d.update({("col", j):[] for j in xrange(9)})
		for i in xrange(9):
			for j in xrange(9):
				ele=board[i][j]
				if ele!=".":
					d[("row", i)].append(ele)
					d[("col", j)].append(ele)
					d[(i//3, j//3)].append(ele)
				else:
					val[(i,j)]=[]
		for (i,j) in val.keys():
			val[(i,j)]=[n for n in num if (n not in d[("row",i)] and
						n not in d[("col",j)] and n not in d[(i/3,j/3)])]
		return val

	def Solver(self,board,val):
		if len(val)==0:
			return True
		kee=min(val.keys(), key=lambda x: len(val[x]))
		nums=val[kee]
		for n in nums:
			(i,j)=kee
			board[i][j]=n
			update={kee:val[kee]}
			del val[kee]
			valid=True
			for ind in val.keys():
				if n in val[ind]:
					if ind[0]==i or ind[1]==j or(ind[0]/3,ind[1]/3)==(i/3,j/3):
					   update[ind]=n
					   val[ind].remove(n)
					   if len(val[ind])==0:
						   valid=False
						   break
			if valid and self.Solver(board,val):
				return True
			else:
				board[i][j]="."
				val=self.undo(update,val)
		return False

	def undo(self, update, val): # add what we deleted back
		for k in update:
			if k not in val:
				val[k]=update[k]
			else:
				val[k].append(update[k])
		return val

Q = [['.',2,'.','.',3,'.','.',4,'.'], [6,'.','.','.','.','.','.','.',3], ['.','.',4,'.','.','.',5,'.','.'], ['.','.','.',8,'.',6,'.','.','.'], [8,'.','.','.',1,'.','.','.',6], ['.','.','.',7,'.',5,'.','.','.'], ['.','.',7,'.','.','.',6,'.','.'], [4,'.','.','.','.','.','.','.',8], ['.',3,'.','.',4,'.','.',2,'.']]

# Q = [['.',3,5,'.','.',1,7,'.','.'], [6,'.','.',9,'.',7,8,'.','.'], ['.',1,'.','.','.','.','.','.',6], ['.',7,4,6,'.','.','.','.',5], [8,'.',3,'.','.','.',9,'.',7], [5,'.','.','.','.',4,6,8,'.'], [3,'.','.','.','.','.','.',1,'.'], ['.','.',6,2,'.',9,'.','.',3], ['.','.',9,7,'.','.',4,6,'.']]


board = []
for row in Q:
	row = map(str, row)
	board.append(row)

# print board

import time

tStart = time.time()

obj = SudokuSolver()
obj.solveSudoku(board)

tEnd = time.time()

for row in board:
	for n in row:
		print n,
	print
print tEnd - tStart