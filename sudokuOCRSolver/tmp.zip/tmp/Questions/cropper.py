from PIL import Image
import glob

images = glob.glob('./Screenshot*.png')
counter = 0

for image in images:
	img = Image.open(image)
	newImg = img.crop((8, 130, 1070, 1185))
	newImg.save('Q' + str(counter) + '.png')
	counter += 1